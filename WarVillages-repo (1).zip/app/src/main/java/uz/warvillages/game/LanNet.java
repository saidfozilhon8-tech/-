package uz.warvillages.game;

import android.webkit.JavascriptInterface;
import android.webkit.WebView;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.Inet4Address;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.NetworkInterface;
import java.net.ServerSocket;
import java.net.Socket;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Enumeration;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Мост между игрой (JS) и обычными TCP-сокетами: два телефона в одной сети или на точке доступа. */
public class LanNet {
    private final WebView web;
    private final ExecutorService out = Executors.newSingleThreadExecutor();
    private volatile ServerSocket server;
    private volatile Socket sock;
    private volatile OutputStream os;
    private volatile int gen = 0;

    public LanNet(WebView web) {
        this.web = web;
    }

    private void emit(final String ev, final String data) {
        web.post(new Runnable() {
            @Override
            public void run() {
                web.evaluateJavascript("window.wvNet&&window.wvNet('" + ev + "'," + JSONObject.quote(data == null ? "" : data) + ")", null);
            }
        });
    }

    @JavascriptInterface
    public String ips() {
        List<String> res = new ArrayList<>();
        try {
            Enumeration<NetworkInterface> en = NetworkInterface.getNetworkInterfaces();
            if (en != null) {
                for (NetworkInterface ni : Collections.list(en)) {
                    if (!ni.isUp() || ni.isLoopback()) continue;
                    for (InetAddress a : Collections.list(ni.getInetAddresses())) {
                        if (a instanceof Inet4Address && !a.isLoopbackAddress()) {
                            res.add(a.getHostAddress());
                        }
                    }
                }
            }
        } catch (Exception ignored) {
        }
        StringBuilder sb = new StringBuilder();
        for (String s : res) {
            if (sb.length() > 0) sb.append(',');
            sb.append(s);
        }
        return sb.toString();
    }

    @JavascriptInterface
    public void host(final int port) {
        stop();
        final int my = ++gen;
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    ServerSocket ss = new ServerSocket();
                    ss.setReuseAddress(true);
                    ss.bind(new InetSocketAddress(port));
                    server = ss;
                    Socket c = ss.accept();
                    if (my != gen) {
                        c.close();
                        return;
                    }
                    try {
                        ss.close();
                    } catch (IOException ignored) {
                    }
                    attach(c, my);
                } catch (Exception e) {
                    if (my == gen) emit("err", "порт занят или сеть недоступна");
                }
            }
        }, "wv-host").start();
    }

    @JavascriptInterface
    public void join(final String ip, final int port) {
        stop();
        final int my = ++gen;
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    Socket c = new Socket();
                    c.connect(new InetSocketAddress(ip, port), 7000);
                    if (my != gen) {
                        c.close();
                        return;
                    }
                    attach(c, my);
                } catch (Exception e) {
                    if (my == gen) emit("err", "нет связи с " + ip);
                }
            }
        }, "wv-join").start();
    }

    private void attach(Socket c, final int my) {
        try {
            c.setTcpNoDelay(true);
            c.setKeepAlive(true);
            sock = c;
            os = c.getOutputStream();
            emit("open", "");
            BufferedReader br = new BufferedReader(new InputStreamReader(c.getInputStream(), StandardCharsets.UTF_8));
            String line;
            while ((line = br.readLine()) != null) {
                if (my != gen) return;
                if (line.length() > 0) emit("msg", line);
            }
        } catch (Exception ignored) {
        }
        if (my == gen) emit("close", "");
    }

    @JavascriptInterface
    public void send(final String msg) {
        final OutputStream o = os;
        if (o == null) return;
        out.execute(new Runnable() {
            @Override
            public void run() {
                try {
                    o.write((msg + "\n").getBytes(StandardCharsets.UTF_8));
                    o.flush();
                } catch (Exception ignored) {
                }
            }
        });
    }

    @JavascriptInterface
    public void stop() {
        gen++;
        os = null;
        try {
            if (sock != null) sock.close();
        } catch (Exception ignored) {
        }
        try {
            if (server != null) server.close();
        } catch (Exception ignored) {
        }
        sock = null;
        server = null;
    }
}
